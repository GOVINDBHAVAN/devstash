"use client"

import { Grid3X3, List, Plus, Filter, Search } from "lucide-react"

import { SidebarTrigger } from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import { collections, itemTypeConfig, type ItemType } from "@/lib/dummy-data"

interface DashboardHeaderProps {
  title: string
  itemCount: number
  viewMode: "grid" | "list"
  onViewModeChange: (mode: "grid" | "list") => void
  activeFilter: string
  activeCollection: string | null
}

export function DashboardHeader({
  title,
  itemCount,
  viewMode,
  onViewModeChange,
  activeFilter,
  activeCollection,
}: DashboardHeaderProps) {
  const collection = activeCollection
    ? collections.find((c) => c.id === activeCollection)
    : null

  return (
    <header className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="flex h-14 items-center gap-4 px-4">
        <SidebarTrigger className="-ml-1" />
        <Separator orientation="vertical" className="h-6" />

        {/* Title */}
        <div className="flex-1 min-w-0">
          <h1 className="text-lg font-semibold truncate text-foreground">
            {collection ? collection.name : title}
          </h1>
          {collection?.description && (
            <p className="text-xs text-muted-foreground truncate hidden sm:block">
              {collection.description}
            </p>
          )}
        </div>

        {/* Search - Desktop */}
        <div className="hidden md:flex relative w-64">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input
            placeholder="Search..."
            className="pl-8 h-9 bg-secondary border-border"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* View Toggle */}
          <ToggleGroup
            type="single"
            value={viewMode}
            onValueChange={(value) => value && onViewModeChange(value as "grid" | "list")}
            className="hidden sm:flex"
          >
            <ToggleGroupItem value="grid" aria-label="Grid view" className="size-9 p-0">
              <Grid3X3 className="size-4" />
            </ToggleGroupItem>
            <ToggleGroupItem value="list" aria-label="List view" className="size-9 p-0">
              <List className="size-4" />
            </ToggleGroupItem>
          </ToggleGroup>

          {/* Filter */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="size-9">
                <Filter className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Filter by Type</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {(Object.keys(itemTypeConfig) as ItemType[]).map((type) => (
                <DropdownMenuItem key={type}>
                  {itemTypeConfig[type].label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* New Item */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" className="gap-2">
                <Plus className="size-4" />
                <span className="hidden sm:inline">New Item</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Create New</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {(Object.keys(itemTypeConfig) as ItemType[]).map((type) => (
                <DropdownMenuItem key={type}>
                  {itemTypeConfig[type].label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Mobile Search */}
      <div className="flex md:hidden px-4 pb-3">
        <div className="relative w-full">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input
            placeholder="Search..."
            className="pl-8 h-9 bg-secondary border-border"
          />
        </div>
      </div>

      {/* Item Count */}
      <div className="px-4 pb-3 text-xs text-muted-foreground">
        {itemCount} {itemCount === 1 ? "item" : "items"}
      </div>
    </header>
  )
}
