"use client"

import {
  Code,
  Command,
  FileText,
  Heart,
  Image,
  Link,
  MessageSquare,
  MoreHorizontal,
  Pin,
  StickyNote,
  Copy,
  Pencil,
  Trash2,
  ExternalLink,
} from "lucide-react"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { type Item, type ItemType, itemTypeConfig } from "@/lib/dummy-data"

const typeIcons: Record<ItemType, React.ElementType> = {
  snippet: Code,
  prompt: MessageSquare,
  note: StickyNote,
  command: Command,
  file: FileText,
  image: Image,
  url: Link,
}

interface ItemCardProps {
  item: Item
  onClick: () => void
}

export function ItemCard({ item, onClick }: ItemCardProps) {
  const Icon = typeIcons[item.type]
  const typeConfig = itemTypeConfig[item.type]

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    })
  }

  return (
    <Card
      className="group cursor-pointer transition-all hover:border-primary/50 hover:bg-card/80 bg-card border-border"
      onClick={onClick}
    >
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <div
              className={cn(
                "flex size-8 shrink-0 items-center justify-center rounded-md border",
                typeConfig.color
              )}
            >
              <Icon className="size-4" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-medium text-sm truncate text-foreground">
                {item.title}
              </h3>
              <p className="text-xs text-muted-foreground">
                {formatDate(item.updatedAt)}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {item.isPinned && (
              <Pin className="size-3.5 text-primary fill-primary" />
            )}
            {item.isFavorite && (
              <Heart className="size-3.5 text-pink-500 fill-pink-500" />
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-7 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <MoreHorizontal className="size-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                <DropdownMenuItem>
                  <Copy className="size-4 mr-2" />
                  Copy
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Pencil className="size-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <ExternalLink className="size-4 mr-2" />
                  Open in Editor
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">
                  <Trash2 className="size-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {item.description && (
          <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
            {item.description}
          </p>
        )}
        {item.content && item.type === "snippet" && (
          <div className="bg-secondary/50 rounded-md p-2 mb-3 overflow-hidden">
            <pre className="text-xs text-muted-foreground font-mono line-clamp-3 overflow-x-auto">
              <code>{item.content}</code>
            </pre>
          </div>
        )}
        {item.content && item.type === "url" && (
          <div className="flex items-center gap-2 text-xs text-primary mb-3 truncate">
            <Link className="size-3 shrink-0" />
            <span className="truncate">{item.content}</span>
          </div>
        )}
        <div className="flex flex-wrap gap-1.5">
          {item.tags.slice(0, 3).map((tag) => (
            <Badge
              key={tag}
              variant="secondary"
              className="text-[10px] px-1.5 py-0 h-5 font-normal"
            >
              {tag}
            </Badge>
          ))}
          {item.tags.length > 3 && (
            <Badge
              variant="secondary"
              className="text-[10px] px-1.5 py-0 h-5 font-normal"
            >
              +{item.tags.length - 3}
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
