"use client"

import {
  Code,
  Command,
  Copy,
  FileText,
  Heart,
  Image,
  Link,
  MessageSquare,
  Pencil,
  Pin,
  Sparkles,
  StickyNote,
  Trash2,
  X,
} from "lucide-react"

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"
import { type Item, type ItemType, itemTypeConfig, collections } from "@/lib/dummy-data"

const typeIcons: Record<ItemType, React.ElementType> = {
  snippet: Code,
  prompt: MessageSquare,
  note: StickyNote,
  command: Command,
  file: FileText,
  image: Image,
  url: Link,
}

interface ItemDrawerProps {
  item: Item | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function ItemDrawer({ item, open, onOpenChange }: ItemDrawerProps) {
  if (!item) return null

  const Icon = typeIcons[item.type]
  const typeConfig = itemTypeConfig[item.type]
  const collection = item.collectionId
    ? collections.find((c) => c.id === item.collectionId)
    : null

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader className="space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div
                className={cn(
                  "flex size-10 shrink-0 items-center justify-center rounded-lg border",
                  typeConfig.color
                )}
              >
                <Icon className="size-5" />
              </div>
              <div>
                <SheetTitle className="text-lg text-foreground">{item.title}</SheetTitle>
                <SheetDescription className="text-sm">
                  {typeConfig.label}
                  {collection && ` · ${collection.name}`}
                </SheetDescription>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "size-8",
                  item.isPinned && "text-primary"
                )}
              >
                <Pin
                  className={cn("size-4", item.isPinned && "fill-current")}
                />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "size-8",
                  item.isFavorite && "text-pink-500"
                )}
              >
                <Heart
                  className={cn("size-4", item.isFavorite && "fill-current")}
                />
              </Button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" size="sm" className="gap-2">
              <Copy className="size-4" />
              Copy
            </Button>
            <Button variant="secondary" size="sm" className="gap-2">
              <Pencil className="size-4" />
              Edit
            </Button>
            {(item.type === "snippet" || item.type === "prompt") && (
              <Button variant="secondary" size="sm" className="gap-2">
                <Sparkles className="size-4 text-primary" />
                AI Actions
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 text-destructive hover:text-destructive"
            >
              <Trash2 className="size-4" />
              Delete
            </Button>
          </div>
        </SheetHeader>

        <Separator className="my-6" />

        {/* Description */}
        {item.description && (
          <div className="mb-6">
            <h4 className="text-sm font-medium mb-2 text-foreground">Description</h4>
            <p className="text-sm text-muted-foreground">{item.description}</p>
          </div>
        )}

        {/* Content */}
        {item.content && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-foreground">Content</h4>
              {item.language && (
                <Badge variant="secondary" className="text-xs">
                  {item.language}
                </Badge>
              )}
            </div>
            {item.type === "url" ? (
              <a
                href={item.content}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-primary hover:underline"
              >
                <Link className="size-4" />
                {item.content}
              </a>
            ) : (
              <div className="bg-secondary rounded-lg p-4 overflow-x-auto">
                <pre className="text-sm font-mono text-foreground whitespace-pre-wrap">
                  <code>{item.content}</code>
                </pre>
              </div>
            )}
          </div>
        )}

        {/* Tags */}
        <div className="mb-6">
          <h4 className="text-sm font-medium mb-2 text-foreground">Tags</h4>
          <div className="flex flex-wrap gap-2">
            {item.tags.map((tag) => (
              <Badge key={tag} variant="outline" className="text-sm">
                {tag}
              </Badge>
            ))}
          </div>
        </div>

        {/* AI Features Placeholder */}
        {(item.type === "snippet" || item.type === "prompt") && (
          <div className="mb-6">
            <h4 className="text-sm font-medium mb-2 flex items-center gap-2 text-foreground">
              <Sparkles className="size-4 text-primary" />
              AI Features
            </h4>
            <div className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start gap-2"
                disabled
              >
                <Sparkles className="size-4" />
                Auto-suggest Tags
                <Badge variant="secondary" className="ml-auto text-xs">
                  Pro
                </Badge>
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start gap-2"
                disabled
              >
                <Sparkles className="size-4" />
                Generate Summary
                <Badge variant="secondary" className="ml-auto text-xs">
                  Pro
                </Badge>
              </Button>
              {item.type === "snippet" && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start gap-2"
                  disabled
                >
                  <Sparkles className="size-4" />
                  Explain Code
                  <Badge variant="secondary" className="ml-auto text-xs">
                    Pro
                  </Badge>
                </Button>
              )}
              {item.type === "prompt" && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start gap-2"
                  disabled
                >
                  <Sparkles className="size-4" />
                  Optimize Prompt
                  <Badge variant="secondary" className="ml-auto text-xs">
                    Pro
                  </Badge>
                </Button>
              )}
            </div>
          </div>
        )}

        <Separator className="my-6" />

        {/* Metadata */}
        <div className="text-xs text-muted-foreground space-y-1">
          <p>Created: {formatDate(item.createdAt)}</p>
          <p>Updated: {formatDate(item.updatedAt)}</p>
        </div>
      </SheetContent>
    </Sheet>
  )
}
