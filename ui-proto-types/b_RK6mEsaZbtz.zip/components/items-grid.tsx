"use client"

import {
  Code,
  Command,
  FileText,
  Heart,
  Image,
  Link,
  MessageSquare,
  MoreHorizontal,
  Pin,
  StickyNote,
  Copy,
  Pencil,
  Trash2,
} from "lucide-react"

import { ItemCard } from "@/components/item-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { type Item, type ItemType, itemTypeConfig } from "@/lib/dummy-data"

const typeIcons: Record<ItemType, React.ElementType> = {
  snippet: Code,
  prompt: MessageSquare,
  note: StickyNote,
  command: Command,
  file: FileText,
  image: Image,
  url: Link,
}

interface ItemsGridProps {
  items: Item[]
  viewMode: "grid" | "list"
  onItemClick: (item: Item) => void
}

export function ItemsGrid({ items, viewMode, onItemClick }: ItemsGridProps) {
  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="size-16 rounded-full bg-secondary flex items-center justify-center mb-4">
          <FileText className="size-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium mb-2 text-foreground">No items found</h3>
        <p className="text-sm text-muted-foreground max-w-sm">
          Create your first item by clicking the &quot;New Item&quot; button above.
        </p>
      </div>
    )
  }

  if (viewMode === "list") {
    return (
      <div className="space-y-2">
        {items.map((item) => (
          <ItemListRow key={item.id} item={item} onClick={() => onItemClick(item)} />
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {items.map((item) => (
        <ItemCard key={item.id} item={item} onClick={() => onItemClick(item)} />
      ))}
    </div>
  )
}

interface ItemListRowProps {
  item: Item
  onClick: () => void
}

function ItemListRow({ item, onClick }: ItemListRowProps) {
  const Icon = typeIcons[item.type]
  const typeConfig = itemTypeConfig[item.type]

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div
      className="group flex items-center gap-4 p-3 rounded-lg border border-border bg-card hover:border-primary/50 hover:bg-card/80 cursor-pointer transition-colors"
      onClick={onClick}
    >
      <div
        className={cn(
          "flex size-9 shrink-0 items-center justify-center rounded-md border",
          typeConfig.color
        )}
      >
        <Icon className="size-4" />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="font-medium text-sm truncate text-foreground">{item.title}</h3>
          {item.isPinned && (
            <Pin className="size-3 text-primary fill-primary shrink-0" />
          )}
          {item.isFavorite && (
            <Heart className="size-3 text-pink-500 fill-pink-500 shrink-0" />
          )}
        </div>
        {item.description && (
          <p className="text-xs text-muted-foreground truncate">{item.description}</p>
        )}
      </div>

      <div className="hidden sm:flex items-center gap-2">
        {item.tags.slice(0, 2).map((tag) => (
          <Badge
            key={tag}
            variant="secondary"
            className="text-[10px] px-1.5 py-0 h-5 font-normal"
          >
            {tag}
          </Badge>
        ))}
      </div>

      <span className="text-xs text-muted-foreground shrink-0 hidden md:block">
        {formatDate(item.updatedAt)}
      </span>

      <DropdownMenu>
        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
          <Button
            variant="ghost"
            size="icon"
            className="size-8 opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
          >
            <MoreHorizontal className="size-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
          <DropdownMenuItem>
            <Copy className="size-4 mr-2" />
            Copy
          </DropdownMenuItem>
          <DropdownMenuItem>
            <Pencil className="size-4 mr-2" />
            Edit
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem className="text-destructive">
            <Trash2 className="size-4 mr-2" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
