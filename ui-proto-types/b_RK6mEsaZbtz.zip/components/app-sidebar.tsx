"use client"

import {
  Code,
  Command,
  FileText,
  FolderOpen,
  Heart,
  Image,
  Link,
  MessageSquare,
  Pin,
  Plus,
  Search,
  Settings,
  StickyNote,
  Clock,
  Sparkles,
  ChevronDown,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { collections, itemTypeConfig, type ItemType } from "@/lib/dummy-data"

const typeIcons: Record<ItemType, React.ElementType> = {
  snippet: Code,
  prompt: MessageSquare,
  note: StickyNote,
  command: Command,
  file: FileText,
  image: Image,
  url: Link,
}

interface AppSidebarProps {
  activeFilter: string
  onFilterChange: (filter: string) => void
  activeCollection: string | null
  onCollectionChange: (collectionId: string | null) => void
}

export function AppSidebar({
  activeFilter,
  onFilterChange,
  activeCollection,
  onCollectionChange,
}: AppSidebarProps) {
  const favoriteCollections = collections.filter((c) => c.isFavorite)
  const allCollections = collections

  return (
    <Sidebar collapsible="icon" className="border-r border-border">
      <SidebarHeader className="border-b border-border pb-4">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" className="group-data-[collapsible=icon]:p-2!">
              <div className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
                <Sparkles className="size-4" />
              </div>
              <div className="flex flex-col gap-0.5 leading-none">
                <span className="font-semibold">DevStash</span>
                <span className="text-xs text-muted-foreground">Store Smarter</span>
              </div>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
        <div className="px-2 pt-2 group-data-[collapsible=icon]:hidden">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
            <Input
              placeholder="Search items..."
              className="pl-8 h-9 bg-secondary border-border"
            />
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        {/* Quick Access */}
        <SidebarGroup>
          <SidebarGroupLabel>Quick Access</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={activeFilter === "all"}
                  onClick={() => {
                    onFilterChange("all")
                    onCollectionChange(null)
                  }}
                  tooltip="All Items"
                >
                  <FolderOpen className="size-4" />
                  <span>All Items</span>
                </SidebarMenuButton>
                <SidebarMenuBadge>47</SidebarMenuBadge>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={activeFilter === "favorites"}
                  onClick={() => {
                    onFilterChange("favorites")
                    onCollectionChange(null)
                  }}
                  tooltip="Favorites"
                >
                  <Heart className="size-4" />
                  <span>Favorites</span>
                </SidebarMenuButton>
                <SidebarMenuBadge>8</SidebarMenuBadge>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={activeFilter === "pinned"}
                  onClick={() => {
                    onFilterChange("pinned")
                    onCollectionChange(null)
                  }}
                  tooltip="Pinned"
                >
                  <Pin className="size-4" />
                  <span>Pinned</span>
                </SidebarMenuButton>
                <SidebarMenuBadge>3</SidebarMenuBadge>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton
                  isActive={activeFilter === "recent"}
                  onClick={() => {
                    onFilterChange("recent")
                    onCollectionChange(null)
                  }}
                  tooltip="Recent"
                >
                  <Clock className="size-4" />
                  <span>Recent</span>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        {/* Types */}
        <SidebarGroup>
          <SidebarGroupLabel>Types</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {(Object.keys(itemTypeConfig) as ItemType[]).map((type) => {
                const Icon = typeIcons[type]
                return (
                  <SidebarMenuItem key={type}>
                    <SidebarMenuButton
                      isActive={activeFilter === type}
                      onClick={() => {
                        onFilterChange(type)
                        onCollectionChange(null)
                      }}
                      tooltip={itemTypeConfig[type].label}
                    >
                      <Icon className="size-4" />
                      <span>{itemTypeConfig[type].label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        {/* Favorite Collections */}
        {favoriteCollections.length > 0 && (
          <>
            <SidebarGroup>
              <SidebarGroupLabel>Starred</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {favoriteCollections.map((collection) => (
                    <SidebarMenuItem key={collection.id}>
                      <SidebarMenuButton
                        isActive={activeCollection === collection.id}
                        onClick={() => {
                          onCollectionChange(collection.id)
                          onFilterChange("all")
                        }}
                        tooltip={collection.name}
                      >
                        <FolderOpen className="size-4" />
                        <span>{collection.name}</span>
                      </SidebarMenuButton>
                      <SidebarMenuBadge>{collection.itemCount}</SidebarMenuBadge>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            <SidebarSeparator />
          </>
        )}

        {/* Collections */}
        <SidebarGroup>
          <SidebarGroupLabel>Collections</SidebarGroupLabel>
          <SidebarGroupAction title="Add Collection">
            <Plus className="size-4" />
          </SidebarGroupAction>
          <SidebarGroupContent>
            <SidebarMenu>
              {allCollections.map((collection) => (
                <SidebarMenuItem key={collection.id}>
                  <SidebarMenuButton
                    isActive={activeCollection === collection.id}
                    onClick={() => {
                      onCollectionChange(collection.id)
                      onFilterChange("all")
                    }}
                    tooltip={collection.name}
                  >
                    <FolderOpen className="size-4" />
                    <span>{collection.name}</span>
                  </SidebarMenuButton>
                  <SidebarMenuBadge>{collection.itemCount}</SidebarMenuBadge>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-border">
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton size="lg">
                  <Avatar className="size-8">
                    <AvatarFallback className="bg-primary/20 text-primary">
                      JD
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col gap-0.5 leading-none text-left">
                    <span className="font-medium text-sm">John Doe</span>
                    <span className="text-xs text-muted-foreground">Free Plan</span>
                  </div>
                  <ChevronDown className="ml-auto size-4" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                side="top"
                align="start"
                className="w-[--radix-dropdown-menu-trigger-width]"
              >
                <DropdownMenuItem>
                  <Sparkles className="size-4 mr-2 text-primary" />
                  Upgrade to Pro
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Settings className="size-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive">
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
