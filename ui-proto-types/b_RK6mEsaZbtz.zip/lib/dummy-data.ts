export type ItemType = 
  | "snippet"
  | "prompt"
  | "note"
  | "command"
  | "file"
  | "image"
  | "url"

export interface Item {
  id: string
  title: string
  type: ItemType
  content?: string
  language?: string
  description?: string
  tags: string[]
  isFavorite: boolean
  isPinned: boolean
  collectionId?: string
  createdAt: string
  updatedAt: string
}

export interface Collection {
  id: string
  name: string
  description?: string
  itemCount: number
  isFavorite: boolean
}

export const collections: Collection[] = [
  {
    id: "1",
    name: "React Patterns",
    description: "Common React patterns and best practices",
    itemCount: 12,
    isFavorite: true,
  },
  {
    id: "2",
    name: "Context Files",
    description: "AI context files for various projects",
    itemCount: 8,
    isFavorite: false,
  },
  {
    id: "3",
    name: "Python Snippets",
    description: "Useful Python code snippets",
    itemCount: 24,
    isFavorite: true,
  },
  {
    id: "4",
    name: "My Prompts",
    description: "AI prompts I use regularly",
    itemCount: 15,
    isFavorite: false,
  },
  {
    id: "5",
    name: "Terminal Commands",
    description: "Frequently used CLI commands",
    itemCount: 32,
    isFavorite: false,
  },
  {
    id: "6",
    name: "API References",
    description: "Bookmarked API documentation",
    itemCount: 19,
    isFavorite: false,
  },
]

export const items: Item[] = [
  {
    id: "1",
    title: "useDebounce Hook",
    type: "snippet",
    content: `import { useState, useEffect } from 'react'

export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)

    return () => {
      clearTimeout(timer)
    }
  }, [value, delay])

  return debouncedValue
}`,
    language: "typescript",
    description: "A custom React hook for debouncing values",
    tags: ["react", "hooks", "typescript"],
    isFavorite: true,
    isPinned: true,
    collectionId: "1",
    createdAt: "2024-01-15T10:30:00Z",
    updatedAt: "2024-01-15T10:30:00Z",
  },
  {
    id: "2",
    title: "Code Review Prompt",
    type: "prompt",
    content: `You are an expert code reviewer. Review the following code for:

1. **Code Quality**: Is the code clean, readable, and well-organized?
2. **Best Practices**: Does it follow industry best practices?
3. **Performance**: Are there any performance concerns?
4. **Security**: Are there any security vulnerabilities?
5. **Edge Cases**: Are edge cases handled properly?

Provide specific, actionable feedback with code examples where appropriate.`,
    description: "Comprehensive code review prompt for AI assistants",
    tags: ["ai", "code-review", "prompt"],
    isFavorite: true,
    isPinned: false,
    collectionId: "4",
    createdAt: "2024-01-14T09:00:00Z",
    updatedAt: "2024-01-14T09:00:00Z",
  },
  {
    id: "3",
    title: "Project Architecture Notes",
    type: "note",
    content: `# Architecture Overview

## Frontend
- Next.js 14 with App Router
- TypeScript for type safety
- Tailwind CSS + shadcn/ui for styling

## Backend
- Neon PostgreSQL database
- Prisma ORM
- NextAuth v5 for authentication

## Key Decisions
- Server Components by default
- Client components only when needed
- Edge functions for API routes`,
    description: "High-level architecture notes for the project",
    tags: ["architecture", "nextjs", "documentation"],
    isFavorite: false,
    isPinned: false,
    collectionId: "2",
    createdAt: "2024-01-13T14:20:00Z",
    updatedAt: "2024-01-13T14:20:00Z",
  },
  {
    id: "4",
    title: "Git Stash Commands",
    type: "command",
    content: `# Stash changes
git stash

# Stash with message
git stash push -m "Work in progress"

# List stashes
git stash list

# Apply most recent stash
git stash pop

# Apply specific stash
git stash apply stash@{2}

# Drop a stash
git stash drop stash@{0}`,
    description: "Common git stash commands for saving work",
    tags: ["git", "cli", "version-control"],
    isFavorite: false,
    isPinned: true,
    createdAt: "2024-01-12T11:45:00Z",
    updatedAt: "2024-01-12T11:45:00Z",
  },
  {
    id: "5",
    title: "Vercel AI SDK Docs",
    type: "url",
    content: "https://sdk.vercel.ai/docs",
    description: "Official documentation for the Vercel AI SDK",
    tags: ["ai", "vercel", "documentation"],
    isFavorite: true,
    isPinned: false,
    createdAt: "2024-01-11T08:30:00Z",
    updatedAt: "2024-01-11T08:30:00Z",
  },
  {
    id: "6",
    title: "Python List Comprehension",
    type: "snippet",
    content: `# Basic list comprehension
squares = [x**2 for x in range(10)]

# With condition
even_squares = [x**2 for x in range(10) if x % 2 == 0]

# Nested comprehension
matrix = [[j for j in range(5)] for i in range(3)]

# Dictionary comprehension
word_lengths = {word: len(word) for word in words}

# Set comprehension
unique_lengths = {len(word) for word in words}`,
    language: "python",
    description: "Python list comprehension examples",
    tags: ["python", "syntax", "basics"],
    isFavorite: false,
    isPinned: false,
    collectionId: "3",
    createdAt: "2024-01-10T16:00:00Z",
    updatedAt: "2024-01-10T16:00:00Z",
  },
  {
    id: "7",
    title: "Docker Compose Template",
    type: "file",
    content: `version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=\${DATABASE_URL}
    depends_on:
      - db

  db:
    image: postgres:15
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
      POSTGRES_DB: myapp
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:`,
    description: "Basic Docker Compose configuration",
    tags: ["docker", "devops", "config"],
    isFavorite: false,
    isPinned: false,
    createdAt: "2024-01-09T13:15:00Z",
    updatedAt: "2024-01-09T13:15:00Z",
  },
  {
    id: "8",
    title: "Explain Code Prompt",
    type: "prompt",
    content: `Explain the following code in plain English:

1. Start with a high-level summary (1-2 sentences)
2. Break down each significant part
3. Explain any complex logic or algorithms
4. Mention any patterns or best practices used
5. Note any potential improvements

Be concise but thorough. Use bullet points for clarity.`,
    description: "Prompt for getting code explanations from AI",
    tags: ["ai", "learning", "prompt"],
    isFavorite: false,
    isPinned: false,
    collectionId: "4",
    createdAt: "2024-01-08T10:00:00Z",
    updatedAt: "2024-01-08T10:00:00Z",
  },
  {
    id: "9",
    title: "React Context Pattern",
    type: "snippet",
    content: `import { createContext, useContext, useState, ReactNode } from 'react'

interface ThemeContextType {
  theme: 'light' | 'dark'
  toggleTheme: () => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<'light' | 'dark'>('light')

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light')
  }

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider')
  }
  return context
}`,
    language: "typescript",
    description: "React Context API pattern with TypeScript",
    tags: ["react", "context", "typescript", "patterns"],
    isFavorite: true,
    isPinned: false,
    collectionId: "1",
    createdAt: "2024-01-07T15:30:00Z",
    updatedAt: "2024-01-07T15:30:00Z",
  },
  {
    id: "10",
    title: "Prisma Cheat Sheet",
    type: "note",
    content: `# Prisma CLI Commands

## Initialize
\`\`\`bash
npx prisma init
\`\`\`

## Generate Client
\`\`\`bash
npx prisma generate
\`\`\`

## Push Schema
\`\`\`bash
npx prisma db push
\`\`\`

## Create Migration
\`\`\`bash
npx prisma migrate dev --name init
\`\`\`

## Open Studio
\`\`\`bash
npx prisma studio
\`\`\``,
    description: "Quick reference for Prisma CLI commands",
    tags: ["prisma", "database", "cli"],
    isFavorite: false,
    isPinned: false,
    createdAt: "2024-01-06T12:00:00Z",
    updatedAt: "2024-01-06T12:00:00Z",
  },
  {
    id: "11",
    title: "NPM Useful Commands",
    type: "command",
    content: `# Check outdated packages
npm outdated

# Update all packages
npm update

# Check for vulnerabilities
npm audit

# Fix vulnerabilities
npm audit fix

# List installed packages
npm list --depth=0

# Clean cache
npm cache clean --force`,
    description: "Useful NPM commands for package management",
    tags: ["npm", "cli", "packages"],
    isFavorite: false,
    isPinned: false,
    collectionId: "5",
    createdAt: "2024-01-05T09:45:00Z",
    updatedAt: "2024-01-05T09:45:00Z",
  },
  {
    id: "12",
    title: "shadcn/ui Documentation",
    type: "url",
    content: "https://ui.shadcn.com",
    description: "Beautiful UI components built with Radix UI and Tailwind",
    tags: ["ui", "components", "tailwind"],
    isFavorite: false,
    isPinned: false,
    collectionId: "6",
    createdAt: "2024-01-04T14:00:00Z",
    updatedAt: "2024-01-04T14:00:00Z",
  },
]

export const itemTypeConfig: Record<ItemType, { label: string; color: string }> = {
  snippet: { label: "Snippet", color: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
  prompt: { label: "Prompt", color: "bg-violet-500/20 text-violet-400 border-violet-500/30" },
  note: { label: "Note", color: "bg-amber-500/20 text-amber-400 border-amber-500/30" },
  command: { label: "Command", color: "bg-cyan-500/20 text-cyan-400 border-cyan-500/30" },
  file: { label: "File", color: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
  image: { label: "Image", color: "bg-pink-500/20 text-pink-400 border-pink-500/30" },
  url: { label: "URL", color: "bg-orange-500/20 text-orange-400 border-orange-500/30" },
}
