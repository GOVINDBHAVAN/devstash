"use client"

import { useState, useMemo } from "react"

import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/app-sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { ItemsGrid } from "@/components/items-grid"
import { ItemDrawer } from "@/components/item-drawer"
import { items, type Item, type ItemType, itemTypeConfig } from "@/lib/dummy-data"

export default function DashboardPage() {
  const [activeFilter, setActiveFilter] = useState<string>("all")
  const [activeCollection, setActiveCollection] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedItem, setSelectedItem] = useState<Item | null>(null)
  const [drawerOpen, setDrawerOpen] = useState(false)

  const filteredItems = useMemo(() => {
    let result = [...items]

    // Filter by collection
    if (activeCollection) {
      result = result.filter((item) => item.collectionId === activeCollection)
    }

    // Filter by type or special filters
    switch (activeFilter) {
      case "favorites":
        result = result.filter((item) => item.isFavorite)
        break
      case "pinned":
        result = result.filter((item) => item.isPinned)
        break
      case "recent":
        result = result.sort(
          (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
        )
        break
      case "all":
        // No additional filtering
        break
      default:
        // Filter by item type
        if (Object.keys(itemTypeConfig).includes(activeFilter)) {
          result = result.filter((item) => item.type === activeFilter)
        }
    }

    // Sort pinned items first
    result.sort((a, b) => {
      if (a.isPinned && !b.isPinned) return -1
      if (!a.isPinned && b.isPinned) return 1
      return 0
    })

    return result
  }, [activeFilter, activeCollection])

  const getTitle = () => {
    if (activeCollection) return "Collection"
    
    switch (activeFilter) {
      case "all":
        return "All Items"
      case "favorites":
        return "Favorites"
      case "pinned":
        return "Pinned"
      case "recent":
        return "Recent"
      default:
        return itemTypeConfig[activeFilter as ItemType]?.label || "Items"
    }
  }

  const handleItemClick = (item: Item) => {
    setSelectedItem(item)
    setDrawerOpen(true)
  }

  return (
    <SidebarProvider>
      <AppSidebar
        activeFilter={activeFilter}
        onFilterChange={setActiveFilter}
        activeCollection={activeCollection}
        onCollectionChange={setActiveCollection}
      />
      <SidebarInset>
        <DashboardHeader
          title={getTitle()}
          itemCount={filteredItems.length}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          activeFilter={activeFilter}
          activeCollection={activeCollection}
        />
        <main className="flex-1 p-4">
          <ItemsGrid
            items={filteredItems}
            viewMode={viewMode}
            onItemClick={handleItemClick}
          />
        </main>
      </SidebarInset>
      <ItemDrawer
        item={selectedItem}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
      />
    </SidebarProvider>
  )
}
